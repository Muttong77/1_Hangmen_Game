import pygame
import math
import random

pygame.init()
SCREEN_WIDTH = 900
SCREEN_HEIGHT = 700
TITLE = ("BREAK BRICK")
pygame.display.set_caption(TITLE)
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
clock = pygame.time.Clock()
pygame.key.set_repeat(1, 1)

#이미지 로드
background_image = pygame.image.load('background_main.jpg')
main_wooden_signboard_image = pygame.image.load('main_wooden_signboard.png')
# 변수
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
WHITE = (255, 255, 255)
YELLOW = (255, 255, 0)
large_font = pygame.font.SysFont('malgungothic', 72)
small_font = pygame.font.SysFont('malgungothic', 36)
score = 0
Time = 0
missed = 0
SUCCESS = 1
FAILURE = 2
game_over = 0
Fever = 0
Fever_gage = [30, 250, 30, 400]
Fever_gage_persent = [35, 255 , 20, 0]
Fever_Time = False
Fever_Time_ball_speed = False
Fever_Time_bar = False
game_start = False
peuse = False
DX = 0
Dy = 0




bricks = []
COLUMN_COUNT = 12
ROW_COUNT = 7
for column_index in range(COLUMN_COUNT):
    for row_index in range(ROW_COUNT):
        brick = pygame.Rect(column_index * (60 + 10) + 35, row_index * (16 + 5) + 35, 60, 16)
        bricks.append(brick)      

ball = pygame.Rect(SCREEN_WIDTH // 2 - 16 // 2, SCREEN_HEIGHT // 2 - 16 // 2, 16, 16)
degree = random.randint(0, 360)

paddle = pygame.Rect(SCREEN_WIDTH // 2 - 80 // 2, SCREEN_HEIGHT - 16, 80, 16)

pygame.mixer.init()
bounce_sound = pygame.mixer.Sound('bounce.wav')
break_sound = pygame.mixer.Sound('break.wav')
success_sound = pygame.mixer.Sound('success.wav')
failure_sound = pygame.mixer.Sound('failure.mp3')
pygame.mixer.music.load('music.mp3')
pygame.mixer.music.play(-1)

# Paddle speed
paddle_speed = 1


#메인화면 설정
while True:
    screen.blit(background_image, (0, 0))
    screen.blit(main_wooden_signboard_image, (-10, SCREEN_HEIGHT/20 - 190))
    main_text = pygame.font.SysFont('Cafe24Decobox.ttf', 140).render('{}'.format(TITLE), True, WHITE)
    screen.blit(main_text, (SCREEN_WIDTH/2-350, SCREEN_HEIGHT/3))
    main_text2 = pygame.font.SysFont('Cafe24Decobox.ttf', 35).render('{}'.format("press space bar to start game"), True, WHITE)
    screen.blit(main_text2, (SCREEN_WIDTH/2-175, SCREEN_HEIGHT/2))
    # 스패이스 바를 불러 게임 시작
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                game_start = True   



        while game_start:
            screen.fill(BLACK)


            # 변수 업데이트
            Time = pygame.time.get_ticks()
            Time_1000 = Time // 1000
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_f:
                        Fever = 400
                    if event.key == pygame.K_ESCAPE:
                            game_start = False
                            peuse = True
                    if event.key == pygame.K_LEFT:
                        paddle.left -= paddle_speed
                    if event.key == pygame.K_RIGHT:
                        paddle.left += paddle_speed

            
            # 패들의 좌표가 화면을 벗어나지 않도록 조정
            if paddle.left < 0:
                paddle.left = 0
            elif paddle.left > SCREEN_WIDTH - paddle.width:
                paddle.left = SCREEN_WIDTH - paddle.width
                    
            if game_over == 0:  
                radian = degree * (math.pi / 180)
                dx = 13 * math.cos(radian)
                dy = -13 * math.sin(radian)
                # 시간이 지남에 따라 공의 속도가 빨라짐
                for i in range(15):
                    if Time_1000 // 5 == i:
                        dx = (13 + i * 2) * math.cos(radian)
                        dy = -(13 + i * 2) * math.sin(radian)
                    # 피버타임이 활성화 되면 공의속도를 2배로 저장
                    if Fever_Time_ball_speed == True:
                        DX = dx * 2
                        DY = dy * 2
                        Fever_Time_ball_speed = False
                # 피버타임의 활성화 여부에 따라 공의 속도를 일반속도 또는 피버타임 속도로 바꿈  

                #피버타임이 아닐때
                if Fever_Time != True:     
                    ball.left += dx
                    ball.top += dy
                
                #피버타임일때
                elif Fever_Time == True:
                    ball.left += DX
                    ball.top += DY

                # 어떤 물체와 부딪혔을때 효과음 출력
                if ball.left <= 0:
                    ball.left = 0
                    degree = 180 - degree
                    bounce_sound.play()

                elif ball.left >= SCREEN_WIDTH - ball.width:
                    ball.left = SCREEN_WIDTH - ball.width
                    degree = 180 - degree
                    bounce_sound.play()
                if ball.top < 0:
                    degree = -degree
                    bounce_sound.play()
                elif ball.top >= SCREEN_HEIGHT:
                    missed += 1
                    ball.left = SCREEN_WIDTH // 2 - ball.width // 2
                    ball.top = SCREEN_HEIGHT // 2 - ball.width // 2
                    degree = random.randint(0, 360)

                if missed >= 3:
                    game_over = FAILURE
                    pygame.mixer.music.stop()
                    failure_sound.play()

                for brick in bricks:
                    if ball.colliderect(brick):
                        bricks.remove(brick)
                        degree = -degree
                        score += 1
                        if Fever <= 400:
                            if Fever_Time != True:
                                Fever += 40
                        break_sound.play()
                        break

                if ball.colliderect(paddle):
                    degree = -degree
                    if ball.centerx <= paddle.left or ball.centerx > paddle.right:
                        degree += 180
                    bounce_sound.play()

                if len(bricks) == 0:
                    print('success')
                    game_over = SUCCESS
                    pygame.mixer.music.stop()
                    success_sound.play()
                    
                # 일시정지   
            while peuse:
                screen.fill(BLACK)
                peuse_text = pygame.font.SysFont('malgungothic', 132).render('{}'.format("일시정지"), True, WHITE)
                screen.blit(peuse_text, (SCREEN_WIDTH/2-260, SCREEN_HEIGHT/3))
                # 스패이스 바를 불러 게임 재개
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        quit()
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_SPACE:
                            game_start = True
                            peuse = False
                pygame.display.update()

            # 화면 그리기
            for brick in bricks:
                pygame.draw.rect(screen, GREEN, brick)
                
            pygame.draw.rect(screen, WHITE, Fever_gage)
            Fever_gage_persent = [35, 645 - Fever, 20, Fever]
            pygame.draw.rect(screen, RED, Fever_gage_persent)
            if Fever >= 400:
                Fever_Time = True
            if Fever_Time == True:
                Fever_Time_ball_speed = True
                Fever -= 2
                if Fever == 0:
                    Fever_Time = False

            if game_over == 0:
                pygame.draw.circle(screen, WHITE, (ball.centerx, ball.centery), ball.width // 2)

            if Fever_Time_bar == False:
                pygame.draw.rect(screen, BLUE, paddle)
            else:
                paddle = pygame.Rect(SCREEN_WIDTH, SCREEN_HEIGHT - 16, 80, 16)
                pygame.draw.rect(screen, BLUE, paddle)

            score_image = small_font.render('점수 {}'.format(score), True, YELLOW)
            screen.blit(score_image, (10, 10))

            missed_image = small_font.render('놓친 공수 {}'.format(missed), True, YELLOW)
            screen.blit(missed_image, missed_image.get_rect(right=SCREEN_WIDTH - 10, top=10))
            
            time_image = small_font.render('시간 {}'.format(Time_1000), True, YELLOW)
            screen.blit(time_image, (150, 10))

            if game_over > 0:
                if game_over == SUCCESS:
                    success_image = large_font.render('성공', True, RED)
                    screen.blit(success_image, success_image.get_rect(centerx=SCREEN_WIDTH // 2, centery=SCREEN_HEIGHT // 2))
                elif game_over == FAILURE:
                    failure_image = large_font.render('실패', True, RED)
                    screen.blit(failure_image, failure_image.get_rect(centerx=SCREEN_WIDTH // 2, centery=SCREEN_HEIGHT // 2))

            pygame.display.update()
            clock.tick(30)
        pygame.display.update()
